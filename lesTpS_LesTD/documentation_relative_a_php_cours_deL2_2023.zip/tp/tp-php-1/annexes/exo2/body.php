<hr/>
<h1>CORPS</h1>
<h1>

Fichier: <?php echo __FILE__ ?>
</h1>
<p>Méthode HTTP utilisée : <?php echo constant("methode");?> </p>
<p>Chemin du fichier en cours d'éxecution <?php echo constant("nomFichier");?></p>
<p>Repertoire du fichier courant/inclus: <?php echo __DIR__;?></p>
