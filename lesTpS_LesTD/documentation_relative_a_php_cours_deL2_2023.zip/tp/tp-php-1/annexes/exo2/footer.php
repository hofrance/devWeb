<hr/><h1>PIED</h1>
<h1>

Fichier: <?php echo __FILE__ ?>
</h1>
<p>
    <a href=<?php echo $url?> ><?php echo $contenu?></a>
</p>
<!-- A COMPLETER -->
</body>