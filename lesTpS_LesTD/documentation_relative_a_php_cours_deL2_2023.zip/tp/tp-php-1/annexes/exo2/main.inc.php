<?php

//la variable du numero de tp
$numTp = 1;
$numExo = 2;
define("leFilename", __FILE__);
define("methode", $_SERVER['REQUEST_METHOD']);
define("nomFichier", $_SERVER['PHP_SELF']);
define("rep",$_SERVER["__DIR__"]);
$url = "http://www.php.net";
$contenu="Le site officiel de PHP";
?>