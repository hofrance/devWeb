<?php
include_once("./main.inc.php");
include("./header.php");
include("./body.php");
include("./footer.php");
?>