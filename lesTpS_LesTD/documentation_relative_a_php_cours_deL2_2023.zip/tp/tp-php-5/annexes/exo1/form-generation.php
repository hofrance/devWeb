<!DOCTYPE html>
<html>
<head>
<title>TP PHP 5.1 - Génération de formulaire</title>
</head>
<body>
<?php
// A COMPLETER
?>
 </body>
</html>
