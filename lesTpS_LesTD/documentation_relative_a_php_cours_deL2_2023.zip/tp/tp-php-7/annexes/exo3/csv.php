<?php
// TODO Lire le fichier countries.csv

// TODO Générer le fichier governments.csv
?>
